// Benjamin Flagg 12/10/2024
// Corner Grocer System

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip> // For formatted output
using namespace std;

// Class for managing frequency data
class FrequencyTracker {
private:
    map<string, int> frequencyMap; // Stores the frequency of each word

public:
    // Reads data from a file and updates the frequency map
    void ReadFromFile(const string& fileName) {
        ifstream inputFile(fileName);
        string word;

        if (inputFile.is_open()) {
            while (inputFile >> word) {
                frequencyMap[word]++;
            }
            inputFile.close();
        }
        else {
            cout << "Error: Unable to open file: " << fileName << endl;
        }
    }

    // Writes the frequency data to a backup file
    void WriteToFile(const string& fileName) {
        ofstream outputFile(fileName);

        if (outputFile.is_open()) {
            for (const auto& item : frequencyMap) {
                outputFile << item.first << " " << item.second << endl;
            }
            outputFile.close();
        }
        else {
            cout << "Error: Unable to write to file: " << fileName << endl;
        }
    }

    // Gets the frequency of a specific word
    int GetFrequency(const string& word) const {
        if (frequencyMap.find(word) != frequencyMap.end()) {
            return frequencyMap.at(word);
        }
        else {
            return 0; // Word not found
        }
    }

    // Prints the frequency of all words
    void PrintFrequencyList() const {
        for (const auto& item : frequencyMap) {
            cout << item.first << " " << item.second << endl;
        }
    }

    // Prints a histogram of the frequencies
    void PrintHistogram() const {
        for (const auto& item : frequencyMap) {
            cout << item.first << " ";
            for (int i = 0; i < item.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }
};

// Main function
int main() {
    FrequencyTracker tracker;
    const string inputFileName = "CS210_Project_Three_Input_File.txt";
    const string backupFileName = "frequency.dat";

    // Read data from the input file
    tracker.ReadFromFile(inputFileName);

    // Create a backup file
    tracker.WriteToFile(backupFileName);

    int choice;
    do {
        // Display menu
        cout << "\nMenu:" << endl;
        cout << "1. Search for a word frequency" << endl;
        cout << "2. Display the frequency list" << endl;
        cout << "3. Display the histogram" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            string word;
            cout << "Enter a word: ";
            cin >> word;
            int freq = tracker.GetFrequency(word);
            cout << "The word '" << word << "' appears " << freq << " times." << endl;
            break;
        }
        case 2:
            cout << "\nFrequency List:" << endl;
            tracker.PrintFrequencyList();
            break;
        case 3:
            cout << "\nHistogram:" << endl;
            tracker.PrintHistogram();
            break;
        case 4:
            cout << "Exiting the program." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 4);

    return 0;
}